# MicroPython on Raspberry Pi Pico

Gareth Halfacree and Ben Everard, [*Get Started With MicroPython on Raspberry Pi Pico*](https://hackspace.raspberrypi.org/books/micropython-pico), 2021
