from django.contrib import admin
from myapp.models import LocationData

# Register your models here.
admin.site.register(LocationData)
