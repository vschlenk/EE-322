from django.contrib import admin
from myapp.models import TemperatureData

# Register your models here.
admin.site.register(TemperatureData)
